# AI Clip Master — Cloud MVP v0.2

This project includes a responsive web dashboard, Android WebView shell, FastAPI backend,
FFmpeg vertical MP4 rendering, and an optional AI-assisted highlight workflow.

## What works now
- Upload a local authorized video file.
- Create 1–10 vertical 9:16 MP4 clips using manually supplied time ranges.
- Auto-clips endpoint: if an OpenAI-compatible API key is configured, transcribe the uploaded video's audio and ask the configured chat model to select highlight ranges from the transcript.
- If no key/transcript is available, the endpoint clearly labels its output as evenly spaced fallback samples. Those are NOT AI-selected highlights.
- Hindi is the default transcription language. English and Bengali can be selected in the UI.
- YouTube publishing remains manual.

## What is not implemented
- Direct arbitrary YouTube/Instagram URL downloading.
- Capturing a live stream from arbitrary platform URLs.
- Reliable visual/gameplay highlight detection. Current AI selection is transcript-based; visual/audio event models are a future milestone.
- Burned-in Hindi subtitles, automatic title/thumbnail, user accounts, billing, production-grade job queue and persistent object storage.

Use only videos you own or have permission to process. Platform terms and privacy rights apply.

## Cloud deploy (Render example)
1. Push this folder to a private Git repository.
2. Create a Render Web Service from the repository using `render.yaml` (root directory `backend`).
3. Add `OPENAI_API_KEY` in the Render service's secret environment variables. Never put this key in web JavaScript or the Android app.
4. Deploy. Test `https://YOUR-API/health`.
5. The current MVP stores uploads/outputs on the container filesystem. For production, attach persistent disk or use S3-compatible object storage; ephemeral files may disappear on redeploy/restart.
6. Restrict CORS in `backend/app/main.py` to your actual dashboard origin. Add file size limits, auth, rate limiting, cleanup, and HTTPS before public launch.

## Run backend locally
```bash
cd backend
python -m venv .venv
source .venv/bin/activate       # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
# Set OPENAI_API_KEY in the server environment if AI highlight selection is desired.
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
FFmpeg and ffprobe must be installed on the server and available on PATH.

## Run web dashboard
Serve `web/` with a static host (HTTPS for production). Set `API_BASE` in `web/app.js`
to the deployed backend HTTPS URL. The page can also be tested with:
```bash
cd web
python -m http.server 8080
```

## Build Android APK
1. Open `android/` in Android Studio.
2. Replace `BASE_URL` in `android/app/src/main/java/com/aiclipmaster/app/MainActivity.kt`
   with your deployed HTTPS dashboard URL.
3. Sync Gradle and run on a device.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
The APK is a WebView shell and requires the cloud dashboard to be online.

## API
- `GET /health`
- `POST /api/upload` multipart `file`
- `POST /api/clips` manual time ranges
- `POST /api/auto-clips` JSON: `{ "video_id":"...", "count":5, "language":"hi", "clip_seconds":35 }`

## Security and production checklist
- Keep API keys server-side only.
- Use HTTPS, authentication, upload size limits, per-user quotas, malware scanning,
  retention/deletion policy, and private object storage.
- Restrict CORS; do not use wildcard origins in production.
- Add background jobs for long videos; HTTP requests may time out for large files.
- Add proper consent/rights checks before processing platform recordings.
