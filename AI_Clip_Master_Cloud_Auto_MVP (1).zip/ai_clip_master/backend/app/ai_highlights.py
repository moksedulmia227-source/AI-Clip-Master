import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any

import requests

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "").strip()
OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
CHAT_MODEL = os.getenv("AI_CHAT_MODEL", "gpt-4o-mini")
TRANSCRIPTION_MODEL = os.getenv("AI_TRANSCRIPTION_MODEL", "whisper-1")

def get_duration(path: Path) -> float:
    cmd = ["ffprobe", "-v", "error", "-show_entries", "format=duration",
           "-of", "default=noprint_wrappers=1:nokey=1", str(path)]
    result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    return max(0.0, float(result.stdout.strip()))

def transcribe(path: Path, language: str = "hi") -> list[dict[str, Any]]:
    """Transcribe an authorized uploaded video using the configured OpenAI-compatible API."""
    if not OPENAI_API_KEY:
        return []
    audio = path.with_suffix(".audio.mp3")
    try:
        subprocess.run(
            ["ffmpeg", "-y", "-i", str(path), "-vn", "-ac", "1", "-ar", "16000",
             "-b:a", "64k", str(audio)],
            check=True, capture_output=True, text=True
        )
        with audio.open("rb") as f:
            response = requests.post(
                f"{OPENAI_BASE_URL}/audio/transcriptions",
                headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
                files={"file": (audio.name, f, "audio/mpeg")},
                data={"model": TRANSCRIPTION_MODEL, "language": language,
                      "response_format": "verbose_json"},
                timeout=600,
            )
        response.raise_for_status()
        payload = response.json()
        return [
            {"start": float(s.get("start", 0)), "end": float(s.get("end", 0)),
             "text": str(s.get("text", "")).strip()}
            for s in payload.get("segments", [])
            if s.get("text")
        ]
    finally:
        audio.unlink(missing_ok=True)

def heuristic_segments(duration: float, count: int, clip_seconds: int) -> list[dict[str, Any]]:
    """Safe fallback when no AI API key is configured; returns spaced sample windows, not AI picks."""
    clip_seconds = max(8, min(clip_seconds, 60))
    if duration <= clip_seconds:
        return [{"start": 0.0, "end": duration, "reason": "Full available video (fallback sample)"}]
    windows = []
    usable = duration - clip_seconds
    for i in range(count):
        start = usable * (i / max(1, count - 1))
        windows.append({"start": round(start, 2), "end": round(start + clip_seconds, 2),
                        "reason": "Evenly spaced fallback; configure AI API for highlight selection"})
    return windows

def choose_highlights(segments: list[dict[str, Any]], duration: float,
                      count: int, clip_seconds: int) -> list[dict[str, Any]]:
    if not segments or not OPENAI_API_KEY:
        return heuristic_segments(duration, count, clip_seconds)

    transcript = "\n".join(
        f"[{s['start']:.1f}-{s['end']:.1f}] {s['text']}" for s in segments
    )
    # Keep the prompt bounded to control token use.
    transcript = transcript[:45000]
    prompt = f"""
You are selecting short, compelling highlights from a video transcript.
Return ONLY valid JSON: {{"clips":[{{"start":12.0,"end":35.0,"reason":"brief reason"}}]}}.
Select up to {count} non-overlapping moments. Each should be 15 to {clip_seconds} seconds.
Use only timestamps covered by the transcript, within 0 and {duration:.1f} seconds.
Prefer complete, understandable moments with strong reactions, useful information,
humor, suspense, or clear story beats. Avoid intros, dead air, repeated moments,
and unsupported assumptions. Do not fabricate events. Transcript:
{transcript}
"""
    response = requests.post(
        f"{OPENAI_BASE_URL}/chat/completions",
        headers={"Authorization": f"Bearer {OPENAI_API_KEY}",
                 "Content-Type": "application/json"},
        json={"model": CHAT_MODEL, "temperature": 0.2,
              "messages":[{"role":"system","content":"Return valid JSON only."},
                          {"role":"user","content":prompt}]},
        timeout=180,
    )
    response.raise_for_status()
    content = response.json()["choices"][0]["message"]["content"]
    content = re.sub(r"^```(?:json)?|```$", "", content.strip(), flags=re.MULTILINE).strip()
    data = json.loads(content)
    clips = []
    for item in data.get("clips", []):
        start = max(0.0, float(item["start"]))
        end = min(duration, float(item["end"]))
        if end > start and 10 <= end-start <= 65:
            clips.append({"start": round(start,2), "end": round(end,2),
                          "reason": str(item.get("reason","AI-selected highlight"))[:180]})
        if len(clips) >= count:
            break
    return clips or heuristic_segments(duration, count, clip_seconds)
