from pathlib import Path
from uuid import uuid4
import shutil
import subprocess

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .ai_highlights import get_duration, transcribe, choose_highlights, OPENAI_API_KEY

BASE = Path(__file__).resolve().parent.parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True)
OUTPUTS.mkdir(exist_ok=True)

app = FastAPI(title="AI Clip Master API", version="0.2.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Set DASHBOARD_ORIGIN and restrict this in production.
    allow_credentials=False, allow_methods=["*"], allow_headers=["*"],
)
app.mount("/files", StaticFiles(directory=str(OUTPUTS)), name="files")

class ClipRange(BaseModel):
    start: float = Field(ge=0)
    end: float = Field(gt=0)

class ClipRequest(BaseModel):
    video_id: str
    clips: list[ClipRange]
    max_clips: int = Field(default=5, ge=1, le=10)

class AutoClipRequest(BaseModel):
    video_id: str
    count: int = Field(default=5, ge=1, le=10)
    language: str = Field(default="hi", max_length=8)
    clip_seconds: int = Field(default=35, ge=15, le=60)

def find_video(video_id: str) -> Path:
    if not video_id.isalnum() or len(video_id) > 64:
        raise HTTPException(400, "Invalid video ID.")
    matches = list(UPLOADS.glob(f"{video_id}.*"))
    if not matches:
        raise HTTPException(404, "Video not found. Upload it again.")
    return matches[0]

def render_clips(source: Path, selected: list[dict], mode: str):
    results = []
    for index, clip in enumerate(selected, start=1):
        start, end = float(clip["start"]), float(clip["end"])
        if end <= start:
            continue
        clip_id = uuid4().hex
        target = OUTPUTS / f"{clip_id}.mp4"
        # Center crop to vertical 9:16. Review framing before publishing.
        vf = "scale=1080:1920:force_original_aspect_ratio=increase,crop=1080:1920"
        command = [
            "ffmpeg", "-y", "-ss", str(start), "-i", str(source),
            "-t", str(end-start), "-vf", vf, "-c:v", "libx264",
            "-preset", "veryfast", "-crf", "23", "-c:a", "aac",
            "-b:a", "128k", "-movflags", "+faststart", str(target)
        ]
        try:
            subprocess.run(command, check=True, capture_output=True, text=True)
        except FileNotFoundError:
            raise HTTPException(500, "FFmpeg is not installed or not on PATH.")
        except subprocess.CalledProcessError as exc:
            raise HTTPException(500, f"FFmpeg failed: {exc.stderr[-1000:]}")
        results.append({
            "clip_number": index, "clip_id": clip_id, "start": start, "end": end,
            "reason": clip.get("reason", "Selected segment"),
            "download_url": f"/files/{clip_id}.mp4"
        })
    return results

@app.get("/health")
def health():
    return {"ok": True, "service": "AI Clip Master", "ai_configured": bool(OPENAI_API_KEY)}

@app.post("/api/upload")
async def upload_video(file: UploadFile = File(...)):
    suffix = Path(file.filename or "video.mp4").suffix.lower()
    if suffix not in {".mp4", ".mov", ".mkv", ".webm", ".m4v"}:
        raise HTTPException(400, "Unsupported video format.")
    video_id = uuid4().hex
    dest = UPLOADS / f"{video_id}{suffix}"
    with dest.open("wb") as out:
        shutil.copyfileobj(file.file, out)
    return {"video_id": video_id, "filename": file.filename, "message": "Upload complete"}

@app.post("/api/clips")
def create_clips(req: ClipRequest):
    if not 1 <= len(req.clips) <= 10:
        raise HTTPException(400, "Choose between 1 and 10 clip ranges.")
    source = find_video(req.video_id)
    selected = [{"start": c.start, "end": c.end, "reason": "Manual selection"}
                for c in req.clips[:req.max_clips]]
    return {"status": "complete", "clips": render_clips(source, selected, "manual")}

@app.post("/api/auto-clips")
def auto_clips(req: AutoClipRequest):
    source = find_video(req.video_id)
    try:
        duration = get_duration(source)
        transcript = transcribe(source, req.language)
        selected = choose_highlights(transcript, duration, req.count, req.clip_seconds)
    except subprocess.CalledProcessError as exc:
        raise HTTPException(500, f"Media analysis failed: {exc.stderr[-1000:]}")
    except Exception as exc:
        raise HTTPException(502, f"AI highlight analysis failed: {str(exc)[:500]}")
    clips = render_clips(source, selected, "auto")
    return {
        "status": "complete", "selection_mode": "AI" if transcript and OPENAI_API_KEY else "fallback",
        "transcript_available": bool(transcript), "clips": clips,
        "notice": None if transcript and OPENAI_API_KEY else
          "AI key not configured or no transcript available; evenly spaced sample clips were created, not AI-selected highlights."
    }
