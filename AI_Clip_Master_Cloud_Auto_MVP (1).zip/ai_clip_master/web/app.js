const API_BASE = "https://YOUR-BACKEND-DOMAIN.example"; // Set to deployed API HTTPS URL.
let videoId = null;
const ranges = document.getElementById("ranges");
function renderRanges(){
  const n=Number(document.getElementById("clipCount").value);ranges.innerHTML="";
  for(let i=1;i<=n;i++){
    const row=document.createElement("div");row.className="range";
    row.innerHTML=`<label>क्लिप ${i} start (seconds)<input type="number" min="0" step="0.1" value="${(i-1)*30}" class="start"></label><label>end (seconds)<input type="number" min="0.1" step="0.1" value="${(i-1)*30+20}" class="end"></label>`;
    ranges.appendChild(row);
  }
}
document.getElementById("clipCount").addEventListener("change",renderRanges);renderRanges();
function showResults(data,target){
  target.innerHTML=(data.clips||[]).map(c=>`<div class="result"><b>Clip ${c.clip_number}</b> (${c.start}s–${c.end}s)<p>${c.reason||""}</p><a href="${API_BASE}${c.download_url}" download>MP4 डाउनलोड करें</a></div>`).join("");
}
document.getElementById("uploadBtn").onclick=async()=>{
  const file=document.getElementById("videoFile").files[0];if(!file){alert("पहले वीडियो फ़ाइल चुनें।");return;}
  const status=document.getElementById("uploadStatus");status.textContent="अपलोड हो रहा है…";
  try{const form=new FormData();form.append("file",file);const r=await fetch(`${API_BASE}/api/upload`,{method:"POST",body:form});const d=await r.json();if(!r.ok)throw Error(d.detail||"Upload failed");
    videoId=d.video_id;status.textContent=`अपलोड पूरा: ${d.filename}`;document.getElementById("autoBtn").disabled=false;document.getElementById("manualBtn").disabled=false;
  }catch(e){status.textContent=`त्रुटि: ${e.message}`;}
};
document.getElementById("autoBtn").onclick=async()=>{
  const status=document.getElementById("autoStatus");status.textContent="AI highlights तैयार हो रहे हैं…";
  try{const r=await fetch(`${API_BASE}/api/auto-clips`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
    video_id:videoId,count:Number(document.getElementById("clipCount").value),
    language:document.getElementById("language").value,clip_seconds:Number(document.getElementById("clipSeconds").value)
  })});const d=await r.json();if(!r.ok)throw Error(d.detail||"AI failed");
    status.textContent=d.notice||"AI क्लिप तैयार हैं।";showResults(d,document.getElementById("results"));
  }catch(e){status.textContent=`त्रुटि: ${e.message}`;}
};
document.getElementById("manualBtn").onclick=async()=>{
  const status=document.getElementById("manualStatus");status.textContent="क्लिप बन रही हैं…";
  try{const clips=[...document.querySelectorAll(".range")].map(el=>({start:Number(el.querySelector(".start").value),end:Number(el.querySelector(".end").value)}));
    const r=await fetch(`${API_BASE}/api/clips`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({video_id:videoId,clips,max_clips:clips.length})});
    const d=await r.json();if(!r.ok)throw Error(d.detail||"Clip generation failed");status.textContent="मैन्युअल क्लिप तैयार हैं।";showResults(d,document.getElementById("results"));
  }catch(e){status.textContent=`त्रुटि: ${e.message}`;}
};
